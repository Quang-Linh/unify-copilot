<?php
echo "PHP fonctionne";
?>

