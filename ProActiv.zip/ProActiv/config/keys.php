<?php
/**
 * Clés de chiffrement ProActiv
 * Généré le 2025-08-27 01:12:00
 * 
 * ⚠️  IMPORTANT : Gardez ces clés secrètes !
 * Ne les committez jamais dans Git
 */

// Clés de sécurité
define('APP_KEY', 'c4579d7e97e788850ff364600bbe4a59d709fd42f2e5851eb4dd2d2201bb91c8');
define('ENCRYPTION_KEY', '6908226ad0188509c72e3e535567062d8fa92b9d3065ac7ba388c622fa1088db');
define('CSRF_KEY', 'aa6db999f223f1ae5452f4621d5a9781');
define('SESSION_KEY', 'bcb20e8a2a1fa045d53c0bc2d36f0c028a16e6ffd0761d10');
define('JWT_SECRET', '8HzJRXLhhF29P1TI9/hOR4fyMo8uEfLwc2D0Uaas01kB7yJJ2fKyiNEuUB4KjXJ8UocKm7sZ+fniB/7OtjK2Lw==');
define('SALT', '2894c6a6ca8ac98d1995561aceeef2e0');

// Configuration supplémentaire
define('ENCRYPTION_CIPHER', 'AES-256-CBC');
define('HASH_ALGORITHM', 'sha256');
define('PASSWORD_PEPPER', 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0');
