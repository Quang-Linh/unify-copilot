import json, time
from pathlib import Path
DATA_BASE = Path(__file__).resolve().parents[3] / 'ged_data' / 'linhstudio'
CANVASES = DATA_BASE / 'canvases'; CANVASES.mkdir(parents=True, exist_ok=True)

class CanvasEngine:
    def save(self, canvas_id: str, shapes):
        if isinstance(shapes, str):
            try: shapes = json.loads(shapes)
            except Exception: shapes = []
        out = CANVASES / f"{canvas_id}.json"
        out.write_text(json.dumps({'id':canvas_id,'shapes':shapes,'ts':int(time.time())}, ensure_ascii=False), encoding='utf-8')
        return {'saved': True, 'file': out.name}
    def load(self, canvas_id: str):
        p = CANVASES / f"{canvas_id}.json"
        return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'id':canvas_id,'shapes':[]}
