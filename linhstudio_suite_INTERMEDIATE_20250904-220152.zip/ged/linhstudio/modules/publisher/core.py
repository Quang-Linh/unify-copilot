import time
from pathlib import Path
DATA_BASE = Path(__file__).resolve().parents[3] / 'ged_data' / 'linhstudio'
PUBLISHED = DATA_BASE / 'publications'; DRAFTS = DATA_BASE / 'drafts'
PUBLISHED.mkdir(parents=True, exist_ok=True); DRAFTS.mkdir(parents=True, exist_ok=True)
TEMPLATES_DIR = Path(__file__).parent / 'templates'

class PublisherEngine:
    def render(self, template_name: str='brochure.html', variables: dict=None, doc_id: str='demo'):
        variables = variables or {}
        tpl_path = TEMPLATES_DIR / template_name
        html = tpl_path.read_text(encoding='utf-8') if tpl_path.exists() else '<h1>{{title}}</h1><div>{{body}}</div>'
        for k,v in variables.items():
            html = html.replace('{{'+k+'}}', str(v))
        out_name = f"{doc_id}-{int(time.time())}.html"
        (PUBLISHED / out_name).write_text(html, encoding='utf-8')
        return {'published': True, 'file': out_name}
    def export(self, **kw): return self.render(**kw)
    def list_templates(self): return {'templates':[p.name for p in TEMPLATES_DIR.glob('*.html')]}
