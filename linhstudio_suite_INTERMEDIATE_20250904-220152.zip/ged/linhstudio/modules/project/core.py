import json
from pathlib import Path
DATA_BASE = Path(__file__).resolve().parents[3] / 'ged_data' / 'linhstudio'
PROJECTS = DATA_BASE / 'projects'; PROJECTS.mkdir(parents=True, exist_ok=True)

class ProjectEngine:
    def get(self, project_id: str='default'):
        p = PROJECTS / f"{project_id}.json"
        return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'columns':{'todo':[],'doing':[],'done':[]}}
    def save(self, project_id: str, board):
        if isinstance(board, str):
            try: board = json.loads(board)
            except Exception: board = {'columns':{'todo':[],'doing':[],'done':[]}}
        p = PROJECTS / f"{project_id}.json"
        p.write_text(json.dumps(board, ensure_ascii=False, indent=2), encoding='utf-8')
        return {'saved': True}
