#!/usr/bin/env python3
import sys, json, os
BASE = os.path.dirname(os.path.dirname(__file__))
MODULES = os.path.join(BASE, 'modules')
sys.path.insert(0, MODULES)

from publisher.core import PublisherEngine
from canvas.core import CanvasEngine
from project.core import ProjectEngine

ENGINES = {'publisher': PublisherEngine, 'canvas': CanvasEngine, 'project': ProjectEngine}

def main():
  req = json.load(sys.stdin)
  module = req.get('module'); action = req.get('action'); payload = req.get('payload',{})
  if module not in ENGINES:
    print(json.dumps({'success': False, 'error': {'code':'bad_module','message':module}})); sys.exit(1)
  engine = ENGINES[module]()
  if not hasattr(engine, action):
    print(json.dumps({'success': False, 'error': {'code':'bad_action','message':action}})); sys.exit(2)
  try:
    data = getattr(engine, action)(**payload)
    print(json.dumps({'success': True, 'data': data}, ensure_ascii=False))
  except Exception as e:
    print(json.dumps({'success': False, 'error': {'code':'exception','message':str(e)}}))
    sys.exit(3)

if __name__=='__main__': main()
