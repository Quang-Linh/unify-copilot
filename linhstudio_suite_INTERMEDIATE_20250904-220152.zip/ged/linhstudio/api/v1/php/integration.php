<?php
require_once __DIR__ . '/../../../app/autoload.php';
use LinhStudio\API\RESTUtils as R;
R::requireAuth();
$cfg = require __DIR__ . '/../../../config/linhstudio.php';

$module = $_GET['module'] ?? $_POST['module'] ?? '';
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$payload = $_POST ?: [];
if(!$module || !$action) R::err('param_missing','module/action requis');

function call_python_cli(array $cfg, array $data){
  $cmd = escapeshellcmd($cfg['python']['python_bin']) . ' ' . escapeshellarg($cfg['python']['runner']);
  $desc=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];
  $proc = proc_open($cmd,$desc,$pipes);
  if(!is_resource($proc)) return ['success'=>false,'error'=>['code'=>'spawn_failed','message'=>'runner']];
  fwrite($pipes[0], json_encode($data)); fclose($pipes[0]);
  $out = stream_get_contents($pipes[1]); fclose($pipes[1]);
  $err = stream_get_contents($pipes[2]); fclose($pipes[2]);
  $code = proc_close($proc);
  if($code!==0) return ['success'=>false,'error'=>['code'=>'py_error','message'=>$err?:'exit '.$code]];
  return json_decode($out,true) ?: ['success'=>false,'error'=>['code'=>'json_parse','message'=>'output']];
}
function call_python_http(array $cfg, array $data){
  $url = rtrim($cfg['python']['flask_url'],'/') . '/v1/integration';
  $ch = curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode($data)]);
  $resp=curl_exec($ch); $err=curl_error($ch); $code=curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  if($err||$code>=400) return ['success'=>false,'error'=>['code'=>'http_error','message'=>$err?:('HTTP '.$code)]];
  return json_decode($resp,true) ?: ['success'=>false,'error'=>['code'=>'json_parse','message'=>'resp']];
}
$req = ['module'=>$module,'action'=>$action,'payload'=>$payload];
$res = ($cfg['python']['mode']==='http') ? call_python_http($cfg,$req) : call_python_cli($cfg,$req);
if(!($res['success']??false)) R::err($res['error']['code']??'unknown',$res['error']['message']??'Erreur',400);
R::ok($res['data']??null);
