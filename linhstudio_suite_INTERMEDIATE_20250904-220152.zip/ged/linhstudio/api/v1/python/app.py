from flask import Flask, request, jsonify
from publisher.core import PublisherEngine
from canvas.core import CanvasEngine
from project.core import ProjectEngine

app = Flask(__name__)
ENG = {'publisher': PublisherEngine, 'canvas': CanvasEngine, 'project': ProjectEngine}

@app.post('/v1/integration')
def integration():
    req = request.get_json(force=True)
    module = req.get('module'); action = req.get('action'); payload = req.get('payload',{})
    if module not in ENG: return jsonify(success=False, error={'code':'bad_module','message':module}), 400
    eng = ENG[module]()
    if not hasattr(eng, action): return jsonify(success=False, error={'code':'bad_action','message':action}), 400
    try:
        data = getattr(eng, action)(**payload)
        return jsonify(success=True, data=data)
    except Exception as e:
        return jsonify(success=False, error={'code':'exception','message':str(e)}), 500

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)
