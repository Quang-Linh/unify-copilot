<?php
return [
  'public_base_url' => '/ged/linhstudio/public',
  'data_path' => realpath(__DIR__ . '/../../ged_data') ?: realpath(__DIR__ . '/../../../ged_data'),
  'python' => [
    'mode' => getenv('LS_PY_MODE') ?: 'cli',
    'python_bin' => getenv('LS_PY_BIN') ?: '/usr/bin/python3',
    'runner' => __DIR__ . '/../api/runner.py',
    'flask_url' => getenv('LS_FLASK_URL') ?: 'http://127.0.0.1:8080',
  ],
];
