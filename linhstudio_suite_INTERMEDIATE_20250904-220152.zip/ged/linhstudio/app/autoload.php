<?php
spl_autoload_register(function ($class) {
    $prefix = 'LinhStudio\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) return;
    $relative = substr($class, strlen($prefix));
    $relativePath = str_replace('\\', DIRECTORY_SEPARATOR, $relative) . '.php';
    $base = __DIR__;
    $file = $base . DIRECTORY_SEPARATOR . $relativePath;
    if (file_exists($file)) require_once $file;
});
