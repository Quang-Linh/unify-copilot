<?php
namespace LinhStudio\API;
final class RESTUtils {
    public static function ok($data = null): void {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
        exit;
    }
    public static function err(string $code, string $message, int $http = 400): void {
        http_response_code($http);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => ['code' => $code, 'message' => $message]], JSON_UNESCAPED_UNICODE);
        exit;
    }
    public static function requireAuth(): void {
        $expected = getenv('LINHSTUDIO_API_KEY') ?: '';
        $key = $_SERVER['HTTP_X_API_KEY'] ?? '';
        if ($expected !== '' && hash_equals($expected, $key)) return;
        if (self::sessionIsValid()) return;
        self::err('auth_required', 'Authentification requise', 401);
    }
    private static function sessionIsValid(): bool {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        return isset($_SESSION['user']) && !empty($_SESSION['user']['id']);
    }
}
